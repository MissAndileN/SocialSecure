// main.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Twilio setup
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const TWILIO_PHONE = process.env.TWILIO_PHONE_NUMBER;

// Simulated database
const users = {
  '+27831234567': { firstName: 'John', registered: true },
  '+27839876543': { firstName: 'Jane', registered: true }
};
const vouchers = {}; // phoneNumber -> {amount, code, otp}

// Helper to generate random codes
function generateCode() {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
}

// Request voucher endpoint
app.post('/request-voucher', async (req, res) => {
  const { phoneNumber, amount } = req.body;

  if (!phoneNumber || !amount) {
    return res.status(400).send({ error: 'Phone number and amount are required.' });
  }

  const user = users[phoneNumber];
  if (!user || !user.registered) {
    return res.send({ message: 'Sorry, your phone number is not registered in the SASSA database.' });
  }

  const voucherCode = `V${Math.floor(1000 + Math.random() * 9000)}`;
  const otp = generateCode();

  vouchers[phoneNumber] = { amount, code: voucherCode, otp };

  try {
    await client.messages.create({
      body: `Hello ${user.firstName}, your R${amount} voucher code is ${voucherCode}. OTP: ${otp}`,
      from: TWILIO_PHONE,
      to: phoneNumber
    });

    res.send({
      message: `You selected a R${amount} voucher. It will be deducted from your next grant + small service fee. Voucher sent via SMS!`
    });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'Failed to send SMS.' });
  }
});

// Redeem voucher endpoint
app.post('/redeem-voucher', (req, res) => {
  const { phoneNumber, otp } = req.body;
  const record = vouchers[phoneNumber];

  if (!record) return res.send({ message: 'No voucher found for this phone number.' });
  if (record.otp !== otp) return res.send({ message: 'Invalid OTP.' });

  delete vouchers[phoneNumber];

  res.send({
    message: `Thank you! Your voucher R${record.amount} has been redeemed. Redeem at participating stores & spaza shops.`
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
